$(document).ready(function(){ 
    $('#ninja3').click(function(){
        $(this).hide(2000);
    });
    $('#ninja4').click(function(){
        $(this).hide(2000);
    });
    //  $('#ninja3').on({
    //     'click': function(){
    //         $('#ninja3').attr('src','cat1.jpg');
    //     }
    // });
    // $('#ninja3').on({
    //     'click': function(){
    //         $('#ninja3').attr('src','cat1.png');
    //     }
    // });
    // $('#ninja4').on({
    //     'click': function(){
    //         $('#ninja4').attr('src','cat2.png');
    //     }
    // });
    $('#ninja2').on({
        'click': function(){
            $('#ninja2').attr('src','cat3.png');
        }
    });
    $('#ninja0').on({
        'click': function(){
            $('#ninja0').attr('src','cat4.png');
        }
    });
});