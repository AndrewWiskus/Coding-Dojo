$(document).ready(function(){ 
    $('img').click(function(){
        $(this).hide(2000);
    });
    $("button").click(function(){
        $("img").show(2000);
    });
});